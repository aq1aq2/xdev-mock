import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class Main {
  public static void main(String[] args) throws Exception {
    HibernateUtil hibernateUtil = new HibernateUtil();
    hibernateUtil.executeSQLCommand("create table event(event_id int,event_date date, title varchar)");
    hibernateUtil.executeSQLCommand("create table person(person_id int,firstname varchar, lastname varchar,age int)");
    hibernateUtil.executeSQLCommand("create table PERSON_EVENT(event_id int, person_id int)");
    Session session = hibernateUtil.getSession();
    
    Event event1 = new Event();
    event1.setTitle("event1");
    Event event2 = new Event();
    event2.setTitle("event2");
    
    Person person1 = new Person();
    person1.setFirstname("person1");
    Person person2 = new Person();
    person2.setFirstname("person2");
    
    person1.getEvents().add(event1);
    person1.getEvents().add(event2);
    
    person2.getEvents().add(event1);
    person2.getEvents().add(event2);
    
    session.save(event1);
    session.save(event2);
    
    session.save(person1);
    session.flush();
    
    person1.getEvents().clear();
    
    session.save(person1);
    session.flush();
    
    session.close();
    hibernateUtil.checkData("select * from event");
    hibernateUtil.checkData("select * from person");
    hibernateUtil.checkData("select * from PERSON_EVENT");
  }
}